from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Category)
admin.site.register(SubCategory)
admin.site.register(Display)
admin.site.register(Processor)
admin.site.register(Memory)
admin.site.register(Camera)
admin.site.register(OtherDetail)
admin.site.register(Image)
admin.site.register(Mobile)
